export default function Home() {
  return (
    <main className="min-h-screen bg-white text-gray-900 p-6 md:p-12">
      <section className="max-w-3xl mx-auto space-y-6">
        <h1 className="text-5xl font-bold leading-tight tracking-tight">Dmitrii Salnikov</h1>
        <p className="text-xl text-gray-600">Backend Systems • API Infrastructure • Automation Architect</p>
        <section>
          <h2 className="text-2xl font-semibold mt-8">Precision-Crafted Infrastructure</h2>
          <p className="text-lg leading-relaxed">
            I design backend systems that scale, integrate, and perform — from stateless microservices to mission-critical automation pipelines.
            Whether you need a custom API layer, backend architecture for a SaaS product, or internal tooling to optimize ops — I ship clean, reliable solutions.
          </p>
        </section>
      </section>
    </main>
  );
}